import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, FlatList } from 'react-native';
import { useState } from 'react';
import ToDoList from './ToDoList';
import ToDoForm from './ToDoForm';
import TodoItemList from './ToDoItemList';
import { Button, TextInput } from 'react-native';
const App = () => {
  //create a state for a variable
  const [name, setName] = useState("")
  //by default an empty string
  return (
      <View style={styles.container}>
          <Text>Hello All!</Text>
          <TextInput placeholder="Enter your name" onChangeText={(text) => setName(text)} />
          {/* pass the prop */}
          <Display name={name} />
      </View>
  );
};

export default function () {
  const [task, setTask] = useState([
    { text: 'Do laundry', key: 1 },
    { text: 'Go to gym', key: 2 },
    { text: 'Walk dog', key: 3 },
  ]);

  const clickHandler = (key) => {
    console.log(key);
    setTask((prevTask) => {
      return prevTask.filter(task => task.key != key);
    })
  }

  return (
    <View style={styles.container}>

   
      <View style={styles.content}>
        <View style={styles.list}>
          <FlatList
            data={task}
            renderItem={({ item }) => (
              <TodoItemList item={item} clickHandler={clickHandler} />
            )}
          />
        </View>
      </View>
      <StatusBar style="auto" />
    </View>
  );
}
const styles = StyleSheet.create({

  container: {
    flex: 1,
    backgroundColor: '#eee',
  },

  content: {
    padding: 12,
  },
  list: {
    marginTop: 30,
  }

});
