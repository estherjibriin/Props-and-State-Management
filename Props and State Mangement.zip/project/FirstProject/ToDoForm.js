import React, { useState } from 'react';
import { View, Button } from 'react-native';

export default function ToDoForm({ onAddStudent}) {
  const [newTask, setNewTask] = useState('');

  const addStudent = () => {
    if (newStudent) {
      onAddStudent(newTask)
      setNewTask('');
    }
  };


  return(
    <View style={styles.student}>
              <Text>{stu.std_name} - {stu.student}</Text>
           <Button title="Add" onPress={addStudent} />
      </View>
      );
    }