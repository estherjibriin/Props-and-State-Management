const arr = [1,2,3,4,5];
const newarr = arr.map(i => i+1);
console.log(newarr)