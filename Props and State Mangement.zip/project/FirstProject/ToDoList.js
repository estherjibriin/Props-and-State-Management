import React from 'react';
import { ScrollView, Pressable, View, Text } from 'react-native';

export default function ToDoList({ student }) {
    return(
        <ScrollView>
        {student.map((stu) => (
          <Pressable key={stu.std_id}>
            <View style={styles.student}>
              <Text>{stu.std_name} - {stu.student}</Text>
            </View>
          </Pressable>
        ))}
      </ScrollView>
    );
}